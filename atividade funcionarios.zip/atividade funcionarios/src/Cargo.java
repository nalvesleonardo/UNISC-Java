public enum Cargo {
    GERENTE,
    ANALISTA,
    DESENVOLVEDOR,
    ANALISTA_DE_SISTEMAS,
    ESTAGIARIO
}
